package com.jmnl2020.chattest;

import android.content.Context;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.ArrayList;

public class RecyclerviewAdapter extends RecyclerView.Adapter {

    Context context;
    ArrayList<CardviewItem> items;

    //받아올 이미지뷰 참조변수
    ImageView iv;

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        //뷰를 만들어주는 메소드

        View itemView = LayoutInflater.from(context).inflate(R.layout.item_cardview, parent, false);
        VH holder = new VH(itemView);

        iv= itemView.findViewById(R.id.cv_img);

        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        VH vh= (VH) holder;

        // 뷰와 정보를 엮어줌

//        CardviewItem item = items.get(position);
//
//        //1. 이미지를 가져와야함
//        //2. db에서 데이터를 가져와야함
//
//        //저장된 이미지를 가져와서 이미지뷰에 넣어 보여주기
//        FirebaseStorage firebaseStorage= FirebaseStorage.getInstance();
//
//        //최상위 폴더 참조객체 얻어오기
//        StorageReference rootRef= firebaseStorage.getReference();
//
//        //읽어오길 원하는 파일의 참조변수 가져오기...?????
//        StorageReference imgRef= rootRef.child("");
//        //=========아마도 객체에서 참조변수를 가져와야하지 않을까? =================
//
//        //참조객체를 찾았으면 이미지의 URL 얻어오기..???????????????????????
//        if(imgRef != null){
//            //참조객체로부터 URL을 얻어오는 작업이 성공했다는 리스너 실행
//            imgRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
//                @Override
//                public void onSuccess(Uri uri) {
//                    Glide.with(context).load(uri).into(iv);
//
//                }
//            });
//        }
//
//
//
//        Glide.with(context).load(item.cvImgfile).into(iv); // ????

    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    class VH extends RecyclerView.ViewHolder {

        ImageView cvImgfile;
        TextView cvTitle;
        TextView cvName;
        TextView cvMsg;

        public VH(@NonNull View itemView) {
            super(itemView);

            cvTitle = itemView.findViewById(R.id.cv_title);
            cvName = itemView.findViewById(R.id.cv_name);
            cvMsg = itemView.findViewById(R.id.cv_msg);
            cvImgfile = itemView.findViewById(R.id.cv_img);

        }
    }

}
