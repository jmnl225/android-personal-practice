package com.jmnl2020.recipieapp;

public class Listview2item {

}
