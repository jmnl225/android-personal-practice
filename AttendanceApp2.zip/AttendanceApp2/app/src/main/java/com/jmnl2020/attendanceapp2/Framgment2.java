package com.jmnl2020.attendanceapp2;

import androidx.fragment.app.Fragment;

public class Framgment2 extends Fragment {
}
