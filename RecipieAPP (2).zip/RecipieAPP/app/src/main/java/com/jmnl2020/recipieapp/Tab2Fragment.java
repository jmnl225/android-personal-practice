package com.jmnl2020.recipieapp;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Tab2Fragment extends Fragment {

    Context context;

    ArrayList<RecyclerViewItem> recyclerViewItems = new ArrayList<>();

    RecyclerView recyclerView;
    MyAdapterRecyclerView adapterRecyclerView;


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tab2, container, false);

        //fagment와 연결된 xml 파일을 여기서 inflate  해 주고, 거기서 나온 view를 받아서 view에 다가 find view by id 해줌.
        // +여기서 아이템 추가

        recyclerViewItems.add(new RecyclerViewItem("시원한 새콤달콤 여름 과일", R.drawable.summerfruits));
        recyclerViewItems.add(new RecyclerViewItem("달콤한 디저트 아이스크림", R.drawable.icebg1));

        adapterRecyclerView = new MyAdapterRecyclerView(context, recyclerViewItems);
        recyclerView = view.findViewById(R.id.recycler);
        recyclerView.setAdapter(adapterRecyclerView);

        return view;
    }
}
