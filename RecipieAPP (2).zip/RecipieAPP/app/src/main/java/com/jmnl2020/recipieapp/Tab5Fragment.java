package com.jmnl2020.recipieapp;

import androidx.fragment.app.Fragment;

public class Tab5Fragment extends Fragment {
}
