package com.jmnl2020.recipieapp;

public class Listview1item {

    String title;
    String name;
    int userimg;
    int mainimg;

    public Listview1item(String title, String name, int userimg, int mainimg){

        this.title= title;
        this.name= name;
        this.userimg= userimg;
        this.mainimg= mainimg;

    }

}
