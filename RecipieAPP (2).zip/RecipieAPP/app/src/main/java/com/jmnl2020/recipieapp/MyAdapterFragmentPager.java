package com.jmnl2020.recipieapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;

public class MyAdapterFragmentPager extends FragmentPagerAdapter {

    Fragment[] fragments= new Fragment[5];
    String[] tabText= {"추천", "분류", "최신", "랭킹", "이슈"};

    public MyAdapterFragmentPager(@NonNull FragmentManager fm) {
        super(fm);

        fragments[0] = new Tab1Fragment();
        fragments[1] = new Tab2Fragment();
        fragments[2] = new Tab1Fragment();
        fragments[3] = new Tab1Fragment();
        fragments[4] = new Tab1Fragment();


    }


    @NonNull
    @Override
    public Fragment getItem(int position) {
        return fragments[position];
    }

    @Override
    public int getCount() {
        return fragments.length;
    }
    //연동시키면 기본적으로 탭버튼에 보여질 글씨를 리턴하는 메소드


    @Nullable
    @Override
    public CharSequence getPageTitle(int position) {
        return tabText[position];
    }
}
