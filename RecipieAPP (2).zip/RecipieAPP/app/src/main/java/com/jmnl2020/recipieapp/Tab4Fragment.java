package com.jmnl2020.recipieapp;

import androidx.fragment.app.Fragment;

public class Tab4Fragment extends Fragment {
}
