package com.jmnl2020.recipieapp;

import android.widget.ImageView;
import android.widget.TextView;

public class RecyclerViewItem {

    String msg;
    int iv;

    public RecyclerViewItem(String tv, int iv) {
        this.msg = tv;
        this.iv = iv;
    }
}
