package com.jmnl2020.animaltest;

public class Post {

    String name;
    String animal;
    String time;
    int iconId;
    int imgId;

    public Post(String name, String animal, String time, int iconId, int imgId){

        this.name= name;
        this.animal= animal;
        this.iconId= iconId;
        this.imgId= imgId;
        this.time = time;

    }

}
