package com.jmnl2020.ex85firebasechatting;

public class G {

    public static String nickName; //채팅명
    public static String profileUri; //프로필 이미지의 Uri 정보

}
