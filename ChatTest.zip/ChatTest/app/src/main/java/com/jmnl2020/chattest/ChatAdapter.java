package com.jmnl2020.chattest;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

import java.util.ArrayList;

public class ChatAdapter extends BaseAdapter {

    Context context;
    ArrayList<MessageItem> messageItems;

    @Override
    public int getCount() {
        return messageItems.size();
    }

    @Override
    public Object getItem(int position) {
        return messageItems.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View itemView= null;

        MessageItem item = messageItems.get(position); //현재 만들어야할 번째의 아이템

        //1. 뷰를 만드는 작업 (new View / create View)
        //채팅창 뷰

        //2. 값을 연결하는 작업

        //여기서 Textview와 Image 뷰 참조변수를 find 해줘서 값을 대입(set) 시킴

        return null;
    }
}
