package com.jmnl2020.chattest;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

public class EditActivity extends AppCompatActivity {

    EditText etName;
    EditText etTitle;
    EditText etMsg;
    ImageView et_iv;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        etMsg = findViewById(R.id.et_msg);
        etTitle= findViewById(R.id.et_title);
        etName= findViewById(R.id.et_name);
        et_iv = findViewById(R.id.et_iv);

    }

    public void clickSelectImage(View view) {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType("image/*");

        startActivityForResult(intent, 100);
    }

    Uri imgUri;

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == 100 && resultCode == RESULT_OK){
            imgUri = data.getData();
            if(imgUri != null){
                Glide.with(EditActivity.this).load(imgUri).into(et_iv);
            }
        }

    }

    public void clickComplete(View view) {
        // 데이터들을 서버로 전송


    }
}
