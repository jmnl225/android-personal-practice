package com.jmnl2020.chattest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ArrayList<CardviewItem> cardviewItems = new ArrayList<>();
    RecyclerviewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //액티비티가 실행될 때

        recyclerView= findViewById(R.id.recycler);


    }

    public void ClickWrite(View view) {
        //write 버튼을 눌렀을때 -> 작성 페이지로 넘어감
        Intent intent = new Intent(this, EditActivity.class);
        startActivity(intent);

    }
}
