package com.jmnl2020.chattest;

public class CardviewItem {

    String cvTitle;
    String cvName;
    String cvMsg;

    String cvImgfile;

    public CardviewItem() {
    }

    public CardviewItem(String cvTitle, String cvName, String cvMsg, String cvImgfile) {
        this.cvTitle = cvTitle;
        this.cvName = cvName;
        this.cvMsg = cvMsg;
        this.cvImgfile = cvImgfile;
    }
}
