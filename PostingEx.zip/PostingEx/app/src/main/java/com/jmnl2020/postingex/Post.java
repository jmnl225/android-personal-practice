package com.jmnl2020.postingex;


public class Post {

    String title;
    String writer;
    String contents;

    public Post(String title, String writer, String contents){

        this.title= title;
        this.writer= writer;
        this.contents= contents;

    }

}
