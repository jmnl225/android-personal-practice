package com.jmnl2020.postingex;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Writing extends AppCompatActivity {

    EditText et_title, et_writer, et_contents;


    //writing 페이지의 java

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_writing);

        et_title= findViewById(R.id.et_title);
        et_writer= findViewById(R.id.et_writer);
        et_contents= findViewById(R.id.et_contents);

    }

    public void clickCancel(View view) {
        //취소 버튼을 눌렀을 때

        finish();

    }

    public void clickOK(View view) {
        //확인 버튼을 눌렀을 때

        //1. Main Activity에 돌려줄 Edit 텍스트 얻어오기
        String title= et_title.getText().toString();
        String writer= et_writer.getText().toString();
        String contents= et_contents.getText().toString();

        // 데이터 돌려주기

        Intent intent= getIntent();
        intent.putExtra("tt", title);
        intent.putExtra("wt", writer);
        intent.putExtra("ct", contents);

        //intent야 이걸 전달해줘~
        setResult(RESULT_OK, intent);

        //이 액티비티 종료
        finish();

    }
}
